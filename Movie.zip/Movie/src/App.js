import React, { Component } from "react";
import { Redirect, Route, Switch } from "react-router-dom";
import Movies from "./Movies";
import Customers from "./components/customers";
import Rentals from "./components/rental";
import NotFound from "./components/Not-Found";
import NavBar from "./components/navBar";
import movies from "./components/movies";
import LoginForm from "./components/LoginForm";
import RegisterForm from "./components/Register";
// import { mongoose as mongoose } from "mongoose";
import "./index.css";

class App extends Component {
  render() {
    return (
      <main className="container">
        <NavBar />
        <Switch>
          <Route path="/register" component={RegisterForm}></Route>
          <Route path="/login" component={LoginForm}></Route>
          <Route path="/movies/:id" component={movies}></Route>
          <Route path="/movies" component={Movies}></Route>
          <Route path="/customers" component={Customers}></Route>
          <Route path="/rental" component={Rentals}></Route>
          <Route path="/Not-Found" component={NotFound}></Route>
          <Redirect from="/" exact to="movies"></Redirect>
          <Redirect to="Not-Found"></Redirect>
        </Switch>
      </main>
    );
  }
}

////

// mongoose
//   .connect("mongodb://localhost/React-database")
//   .then(console.log("Connected to MongoDB..."))
//   .catch((err) => console.error("Error while connecting to MongoDB ", err));

// const RegisterSchema = new mongoose.Schema({
//   name: {
//     type: "string",
//     min: "5",
//     max: "50",
//     required: true,
//   },
//   email: {
//     type: "string",
//     unique: true,
//   },
//   password: {
//     type: "string",
//     min: "8",
//   },
// });

// const Register = mongoose.model("Register", RegisterSchema);

// async function registerUser() {
//   const register = new Register({
//     name: "Abdul Wahid",
//     email: "abdul@gmail.com",
//     password: "Abdulwahid",
//   });

//   const result = await register.save();
//   console.log(result);
// }

// async function remove() {
//   const account = await Register.findById("660af07e165556376c0b87d8");
//   console.log(account);
//   account.remove();
//   account.save();
//   console.log("Account removed");
// }

// // remove();

// registerUser();

export default App;
