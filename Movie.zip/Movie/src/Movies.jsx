import "bootstrap/dist/css/bootstrap.css";
import React, { Component } from "react";
import Page from "./components/common/pagination";
import { paginate } from "./utills/paginate";
import ListGroup from "./components/common/listGroup";
import { getGenres } from "./services/fakeGenreService";
import { getMovies } from "./services/fakeMovieService";
import MoviesTable from "./components/common/movieTable";
import _ from "lodash";
import "./index.css";
import { Link } from "react-router-dom";

class Movies extends Component {
  state = {
    movies: [],
    genre: [],
    pageSize: 4,
    currentPage: 1,
    sortColumn: { path: "title", sortOrder: "asc" },
  };

  componentDidMount() {
    const genres = [{ _id: "", name: "All Genres" }, ...getGenres()];
    this.setState({ movies: getMovies(), genre: genres });
  }
  handleSelectGenre = (genre) => {
    this.setState({ selectedGenre: genre, currentPage: 1 });
  };
  handleDelete = (movie) => {
    const movies = this.state.movies.filter((m) => m._id !== movie._id);
    this.setState({ movies });
  };

  handleLike = (movie) => {
    const movies = [...this.state.movies];
    const index = movies.indexOf(movie);
    movie[index] = { ...movies[index] };
    movies[index].liked = !movies[index].liked;
    this.setState({ movies });
  };

  handlePageChange = (page) => {
    this.setState({ currentPage: page });
  };

  handleSort = (sortColumn) => {
    this.setState({ sortColumn });
  };

  render() {
    const moviesCount = this.state.movies.length;
    if (moviesCount === 0) {
      return <h5 className="mt-4 ml-4">There are no movies in database.</h5>;
    }
    const {
      selectedGenre,
      movies: allmovies,
      currentPage,
      pageSize,
      sortColumn,
    } = this.state;

    const filteredMovies =
      selectedGenre && selectedGenre._id
        ? allmovies.filter((m) => m.genre._id === selectedGenre._id)
        : allmovies;

    const sorted = _.orderBy(
      filteredMovies,
      [sortColumn.path],
      [sortColumn.sortOrder]
    );

    const movies = paginate(sorted, currentPage, pageSize);

    return (
      <React.Fragment>
        <div className="container">
          <div className="row">
            <div className="offset-2 col-md-2">
              <ListGroup
                allGenreItems={getGenres()}
                items={this.state.genre}
                selectedItem={this.state.selectedGenre}
                onSelectiItem={this.handleSelectGenre}
              />
            </div>

            <div className="col-md-8">
              <Link to="/">
                <button className=" add-new-movie btn btn-primary">
                  New Movie
                </button>
              </Link>
              <h5 className="mt-4">
                Showing {filteredMovies.length} movies in database.
              </h5>
              <MoviesTable
                movies={movies}
                sortColumn={sortColumn}
                onDelete={this.handleDelete}
                onLike={this.handleLike}
                onSort={this.handleSort}
              />

              <div className="paagination">
                <Page
                  pageCount={filteredMovies.length}
                  pageSize={this.state.pageSize}
                  onPageChange={this.handlePageChange}
                  currentPage={this.state.currentPage}
                />
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default Movies;
