import React from "react";
import { getMovie } from "./../services/fakeMovieService";

const movies = ({ match, history }) => {
  return (
    <React.Fragment>
      <h1>Movie number : {match.params.id}</h1>

      <button
        className="btn btn-primary"
        onClick={() => history.push("/movies")}
      >
        Save
      </button>
    </React.Fragment>
  );
};

export default movies;
