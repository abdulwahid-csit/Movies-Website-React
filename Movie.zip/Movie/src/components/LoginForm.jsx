import React, { Component } from "react";
import { Joi } from "joi-browser";
import Input from "./common/Input";

class LoginForm extends Component {
  state = {
    account: { username: "", password: "" },
    errors: {},
  };

  validate = () => {
    const erros = {};
    if (this.state.account.username.trim() === "")
      erros.username = "Username is required.";
    if (this.state.account.password.trim() === "")
      erros.password = "Password is required.";

    return Object.keys(erros).length === 0 ? null : erros;
  };

  handleForm = (e) => {
    e.preventDefault();
    const erros = this.validate();
    this.setState({ errors: erros || {} });
    if (erros) return;
    console.log("submitted");
  };

  handleChange = ({ currentTarget: input }) => {
    const errors = { ...this.state.errors };
    const errorMessage = this.validateProperty(input);
    if (errorMessage) errors[input.name] = errorMessage;
    else delete errors[input.name];

    const account = { ...this.state.account };
    account[input.name] = input.value;
    this.setState({ account, errors });
  };

  validateProperty = ({ name, value }) => {
    if (name === "username") {
      if (value.trim() === "") return "Username is required.";
      //.....
    }
    if (name === "password") {
      if (value.trim() === "") return "Password is required.";
      //.....
    }
  };
  render() {
    const { account, errors } = this.state;
    return (
      <div>
        <h1>Login</h1>
        <form onSubmit={this.handleForm}>
          <Input
            Name="username"
            label="Username"
            type="text"
            onChange={this.handleChange}
            value={account.username}
            errors={errors.username}
          />
          <Input
            Name="password"
            label="Password"
            type="password"
            onChange={this.handleChange}
            value={account.password}
            errors={errors.password}
          />

          <button disabled={this.validate()} className="btn btn-primary">
            Login
          </button>
        </form>
      </div>
    );
  }
}

export default LoginForm;
