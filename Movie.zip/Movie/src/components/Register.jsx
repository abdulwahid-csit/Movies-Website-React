import React, { Component } from "react";
import Input from "./common/Input";

class RegisterForm extends Component {
  state = {
    account: { username: "", password: "", name: "" },
    errors: {},
  };

  validate = () => {
    const erros = {};
    if (this.state.account.username.trim() === "")
      erros.username = "Enter a valid email.";
    if (this.state.account.password.length < 6)
      erros.password = "Password must be 6 characters or long.";
    if (this.state.account.name.trim() === "")
      erros.password = "Name is required.";

    return Object.keys(erros).length === 0 ? null : erros;
  };

  handleForm = (e) => {
    e.preventDefault();
    const erros = this.validate();
    this.setState({ errors: erros || {} });
    if (erros) return;
    console.log("submitted");
  };

  handleChange = ({ currentTarget: input }) => {
    const errors = { ...this.state.errors };
    const errorMessage = this.validateProperty(input);
    if (errorMessage) errors[input.name] = errorMessage;
    else delete errors[input.name];

    const account = { ...this.state.account };
    account[input.name] = input.value;
    this.setState({ account, errors });
  };

  validateProperty = ({ name, value }) => {
    if (name === "username") {
      if (value.trim() === "") return "Write a valid email.";
      //.....
    }
    if (name === "password") {
      if (value.length < 6) return "Password must be 6 characters or long.";
      //.....
    }
    if (name === "name") {
      if (value.trim() === "") return "Name is required.";
      //.....
    }
  };
  render() {
    const { account, errors } = this.state;
    return (
      <div>
        <h1>Login</h1>
        <form onSubmit={this.handleForm}>
          <Input
            Name="username"
            label="Username"
            type="email"
            onChange={this.handleChange}
            value={account.username}
            errors={errors.username}
          />
          <Input
            Name="password"
            label="Password"
            type="password"
            onChange={this.handleChange}
            value={account.password}
            errors={errors.password}
          />
          <Input
            Name="name"
            label="Name"
            type="text"
            onChange={this.handleChange}
            value={account.name}
            errors={errors.name}
          />

          <button disabled={this.validate()} className="btn btn-primary">
            Register
          </button>
        </form>
      </div>
    );
  }
}

export default RegisterForm;
