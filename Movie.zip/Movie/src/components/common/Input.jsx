import React from "react";

const Input = ({ Name, label, errors, ...rest }) => {
  return (
    <div className="form-group">
      <label htmlFor={Name}>{label}</label>
      <input {...rest} id={Name} name={Name} className="form-control"></input>
      {errors && <div className="alert alert-danger">{errors}</div>}
    </div>
  );
};

export default Input;
