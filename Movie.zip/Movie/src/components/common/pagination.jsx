import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import _ from 'lodash';


class Page extends Component {
    state = {} 

    render() {
        const  {pageCount, pageSize, onPageChange, currentPage} = this.props;
        const numberOfPages =  Math.ceil(pageCount / pageSize);
        const pages = _.range(1, numberOfPages + 1);
        if(numberOfPages === 1) {return null;};
        
        return (
            <React.Fragment> 
            
            <nav className='Page navigation example'>
                <ul className='pagination'>
                {pages.map(page =>  (
                    <li key={page} className={currentPage === page?'page-item active': 'page-item'}>
                    <a onClick={() => onPageChange(page)}  className='page-link'>{page}</a></li>
                    
                    ))}
                    
                </ul>
            </nav>
            
            </React.Fragment>
        );
    }
}
 
export default Page;