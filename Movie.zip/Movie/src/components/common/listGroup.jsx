import React from "react";
import "bootstrap/dist/css/bootstrap.css";

const ListGroup = (props) => {
  const { items, textProperty, valueProperty, onSelectiItem, selectedItem } =
    props;
  return (
    <ul className="list-group mt-4">
      {items.map((item) => (
        <li
          onClick={() => onSelectiItem(item)}
          key={item[valueProperty]}
          className={
            item === selectedItem ? "list-group-item active" : "list-group-item"
          }
        >
          {item[textProperty]}
        </li>
      ))}
    </ul>
  );
};

ListGroup.defaultProps = {
  textProperty: "name",
  valueProperty: "_id",
};
export default ListGroup;
