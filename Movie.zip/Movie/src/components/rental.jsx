import React from "react";
import { useState } from "react";

const Rentals = () => {
  return <h1>Rentals</h1>;
};

export default Rentals;
